
import random
import string

def generate_sku(name):
    name_code = name[:3].upper()          # Take first 3 letters of name
    random_number = ''.join(random.choices(string.digits, k=6))  # Generate 4-digit random number
    return f"{name_code}{random_number}"


#sku = generate_sku("Fertilizer", "Organic")