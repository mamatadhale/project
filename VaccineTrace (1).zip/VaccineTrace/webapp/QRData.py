from pyzbar.pyzbar import decode
from PIL import Image
import json

def decode_qr(image_path):
    """
    Decodes a QR code from an image file.

    :param image_path: Path to the QR code image file
    :return: Decoded data (dictionary if JSON, otherwise string)
    """
    # Open the image
    image = Image.open(image_path)

    # Decode QR Code
    decoded_data = decode(image)
    
    if decoded_data:
        qr_text = decoded_data[0].data.decode("utf-8")  # Extract text data
        
        # Try parsing as JSON
        try:
            return json.loads(qr_text)  # Convert to dictionary if JSON
        except json.JSONDecodeError:
            return qr_text  # Return as string if not JSON
    else:
        return None

# Example Usage
if __name__ == "__main__":
    image_path = "download.png"  # Replace with your QR code image file path
    result = decode_qr(image_path)
    print("Decoded Data:", type(result))
    print("Decoded Data:", result)
