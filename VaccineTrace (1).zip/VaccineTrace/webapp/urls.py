"""WebC URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import views


urlpatterns = [ 


    path('', views.homepage, name="WelcomeHome"),
    path('adminlogin/', views.adminlogin, name="adminlogin"),
    path('adminloginaction/', views.adminloginaction, name="adminloginaction"),
    path('adminhome/', views.adminhome, name="adminhome"),
    path('adminlogout/', views.adminlogout, name="adminlogout"),
    path('viewmanufacturers/', views.viewmanufacturers, name="viewmanufacturers"),
    path('viewdistributers/', views.viewdistributers, name="viewdistributers"),
    path('acceptor/', views.acceptor, name="acceptor"),
    
    
    path('msignupaction/', views.msignupaction, name="msignupaction"),
    path('manufacturer/', views.manufacturer, name="manufacturer"),
    path('mloginaction/', views.mloginaction, name="mloginaction"),
    path('mhome/', views.mhome, name="mhome"),
    path('mlogout/', views.mlogout, name="mlogout"),
    path('thome/', views.thome, name="thome"),
    path('tlogout/', views.tlogout, name="tlogout"),
    path('addvaccine/', views.addvaccine, name="addvaccine"),
    path('mviewvaccine/', views.mviewvaccine, name='mviewvaccine'),
    path('addstock/', views.addstock, name="addstock"),
    
    
    path('dsignupaction/', views.dsignupaction, name="dsignupaction"),
    path('distributer/', views.distributer, name="distributer"),
    path('dloginaction/', views.dloginaction, name="dloginaction"),
    path('dhome/', views.dhome, name="dhome"),
    path('dlogout/', views.dlogout, name="dlogout"),
    path('dviewvaccine/', views.dviewvaccine, name="dviewvaccine"),
    path('pstockget/', views.pstockget, name="pstockget"),
    
    
    path('usignupaction/', views.usignupaction, name="usignupaction"),
    path('user/', views.user, name="user"),
    path('uloginaction/', views.uloginaction, name="uloginaction"),
    path('uhome/', views.uhome, name="uhome"),
    path('ulogout/', views.ulogout, name="ulogout"),
    path('manageaddress/', views.manageaddress, name="manageaddress"),
    path('profile/', views.profile, name="profile"),
    path('deleteaddress/', views.deleteaddress, name="deleteaddress"),
    path('morders/', views.morders, name="morders"),
    path('morderview/', views.morderview, name="morderview"),
    path('transporter/', views.transporter, name="transporter"),
    path('tloginaction/', views.tloginaction, name="tloginaction"),
    path('transfer/', views.transfer, name="transfer"),
    path('delivery/', views.delivery, name="delivery"),
    path('delivered/', views.delivered, name="delivered"),
    path('orderstatus/', views.orderstatus, name="orderstatus"),
    path('inventory/', views.inventory, name='inventory'),
    path('viewvaccine/', views.viewvaccine, name='viewvaccine'),
    path('viewdata/<str:op>/', views.viewdata, name="viewdata"),
    path('addtocart/', views.addtocart, name="addtocart"),
    path('uviewcart/', views.uviewcart, name="uviewcart"),
    path('payment_u/', views.payment_u, name="payment_u"),

    path('vieworders/', views.vieworders, name="vieworders"),
    path('verify/', views.verify, name="verify"),
    path('dvieworders/', views.dvieworders, name="dvieworders"),
    path('verify/', views.verify, name="verify"),
    path('dropimage/', views.dropimage, name="dropimage"),
    path('d_dropimage/', views.d_dropimage, name="d_dropimage"),
    path('dropimageaction/', views.dropimageaction, name="dropimageaction"),
    
    path('viewres/', views.viewres, name="viewres"),
    path('viewres2/', views.viewres2, name="viewres2"),
    path('getall/', views.getall, name="getall"),

    path('viewalerts/', views.viewalerts, name="viewalerts"),

    
    
    

   
]





# Ensure Django serves media files in development
from django.conf import settings
from django.conf.urls.static import static


# Serve media files during development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
