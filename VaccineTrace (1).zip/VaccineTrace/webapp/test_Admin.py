import os
import time
import requests
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

# Correct initialization for selenium 4.x
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service)

def wait_for_server(url):
    """Waits until the server is running."""
    print(f"⏳ Checking if server is running at {url}...")
    while True:
        try:
            response = requests.get(url)
            if response.status_code == 200:
                print("✅ Server is up and running!")
                break
        except requests.exceptions.ConnectionError:
            pass
        time.sleep(2)

def test_manufacturer_signup():
    """Test for manufacturer signup functionality"""
    driver.get("http://localhost:8000/manufacturer/")

    # Signup
    driver.find_element(By.NAME, "mail").send_keys("manufacturer@test.com")
    driver.find_element(By.NAME, "pass_word").send_keys("password123")
    driver.find_element(By.NAME, "name").send_keys("Test Manufacturer")
    driver.find_element(By.NAME, "city").send_keys("Test City")
    driver.find_element(By.NAME, "add").send_keys("123 Test Street")
    driver.find_element(By.CSS_SELECTOR, "input[type='submit']").click()

    time.sleep(2)  # Wait for the page to load

    # Verify successful registration message
    assert "Register Success.." in driver.page_source, "Manufacturer signup failed"

def test_manufacturer_login():
    """Test for manufacturer login functionality"""
    driver.get("http://localhost:8000/manufacturer/")

    # Login
    driver.find_element(By.NAME, "mail").send_keys("manufacturer@test.com")
    driver.find_element(By.NAME, "pass_word").send_keys("password123")
    driver.find_element(By.CSS_SELECTOR, "input[type='submit']").click()

    time.sleep(2)  # Wait for the page to load

    # Verify successful login (should redirect to the manufacturer home page)
    assert "m_home.html" in driver.current_url, "Manufacturer login failed"

def test_distributer_signup():
    """Test for distributor signup functionality"""
    driver.get("http://localhost:8000/distributer/")

    # Signup
    driver.find_element(By.NAME, "mail").send_keys("distributer@test.com")
    driver.find_element(By.NAME, "pass_word").send_keys("password123")
    driver.find_element(By.NAME, "name").send_keys("Test Distributer")
    driver.find_element(By.NAME, "city").send_keys("Test City")
    driver.find_element(By.NAME, "add").send_keys("123 Test Street")
    driver.find_element(By.NAME, "phone").send_keys("1234567890")
    driver.find_element(By.NAME, "type").send_keys("Wholesaler")
    driver.find_element(By.CSS_SELECTOR, "input[type='submit']").click()

    time.sleep(2)  # Wait for the page to load

    # Verify successful registration message
    assert "Register Success.." in driver.page_source, "Distributor signup failed"

def test_distributer_login():
    """Test for distributor login functionality"""
    driver.get("http://localhost:8000/distributer/")

    # Login
    driver.find_element(By.NAME, "mail").send_keys("distributer@test.com")
    driver.find_element(By.NAME, "pass_word").send_keys("password123")
    driver.find_element(By.CSS_SELECTOR, "input[type='submit']").click()

    time.sleep(2)  # Wait for the page to load

    # Verify successful login (should redirect to the distributor home page)
    assert "d_home.html" in driver.current_url, "Distributor login failed"

def test_user_signup():
    """Test for user signup functionality"""
    driver.get("http://localhost:8000/users/")

    # Signup
    driver.find_element(By.NAME, "mail").send_keys("user@test.com")
    driver.find_element(By.NAME, "pass_word").send_keys("password123")
    driver.find_element(By.NAME, "name").send_keys("Test User")
    driver.find_element(By.NAME, "phone").send_keys("1234567890")
    driver.find_element(By.CSS_SELECTOR, "input[type='submit']").click()

    time.sleep(2)  # Wait for the page to load

    # Verify successful registration message
    assert "Register Success.." in driver.page_source, "User signup failed"

def test_user_login():
    """Test for user login functionality"""
    driver.get("http://localhost:8000/users/")

    # Login
    driver.find_element(By.NAME, "mail").send_keys("user@test.com")
    driver.find_element(By.NAME, "pass_word").send_keys("password123")
    driver.find_element(By.CSS_SELECTOR, "input[type='submit']").click()

    time.sleep(2)  # Wait for the page to load

    # Verify successful login (should redirect to the user home page)
    assert "u_home.html" in driver.current_url, "User login failed"

def run_tests():
    """Run all the test cases"""
    print("🚀 Running Selenium tests...")

    # Optionally wait for the server to start before running the tests
    wait_for_server("http://localhost:8000")

    try:
        test_manufacturer_signup()
        test_manufacturer_login()
        test_distributer_signup()
        test_distributer_login()
        test_user_signup()
        test_user_login()

        print("✅ All tests passed!")

    except AssertionError as e:
        print("❌ Test failed:", e)

    finally:
        driver.quit()

if __name__ == "__main__":
    run_tests()
