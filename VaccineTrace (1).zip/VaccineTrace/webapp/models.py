from django.db import models

class manufacturers(models.Model):
	name=models.CharField(max_length=159);
	email=models.CharField(max_length=159);
	pass_word=models.CharField(max_length=159);
	city=models.CharField(max_length=159);
	address=models.CharField(max_length=159);
	stz=models.CharField(max_length=159);

class distributers(models.Model):
	name=models.CharField(max_length=159);
	typ_e=models.CharField(max_length=159);
	email=models.CharField(max_length=159);
	pass_word=models.CharField(max_length=159);
	phone=models.CharField(max_length=20, default='');
	city=models.CharField(max_length=159);
	address=models.CharField(max_length=159);

class users(models.Model):
	name=models.CharField(max_length=159);
	email=models.CharField(max_length=159);
	phone=models.CharField(max_length=159);
	pass_word=models.CharField(max_length=159);

class user_address(models.Model):
	email=models.CharField(max_length=159);
	address=models.CharField(max_length=159);
	addr_type=models.CharField(max_length=159);
	city=models.CharField(max_length=159);
	zip=models.CharField(max_length=159);

class vaccine(models.Model):
	name=models.CharField(max_length=159);
	size=models.CharField(max_length=159);
	description=models.TextField();
	usage=models.TextField();
	availability=models.IntegerField();
	mrp=models.FloatField();
	selling_price=models.FloatField();
	image=models.CharField(max_length=500);
	email=models.CharField(max_length=500);
	company_name=models.CharField(max_length=500);


class vaccine_stock(models.Model):
	sku=models.CharField(max_length=159);
	pid=models.CharField(max_length=19);
	pname=models.CharField(max_length=159);
	manufacturer=models.CharField(max_length=159);
	distributer=models.CharField(max_length=159);
	user=models.CharField(max_length=159);

class DistributerOrders(models.Model):
    orderid = models.CharField(max_length=19)
    pid = models.CharField(max_length=19)
    pname = models.CharField(max_length=159)
    quantity = models.IntegerField()
    cost = models.FloatField()
    tot_cost = models.FloatField()
    manufacturer = models.CharField(max_length=159)
    manufacturer_name = models.CharField(max_length=159)
    distributer_name = models.CharField(max_length=159)
    distributer_email = models.CharField(max_length=159)
    date = models.DateField(auto_now_add=True)
    status = models.CharField(max_length=159, default='Order Initiated')


class Transport(models.Model):
    orderid=models.CharField(max_length=159);
    manufacturer = models.CharField(max_length=159);
    manufacturer_name = models.CharField(max_length=159);
    distributer_name = models.CharField(max_length=159);
    distributer_email = models.CharField(max_length=159);
    phone=models.CharField(max_length=20, default='');
    city=models.CharField(max_length=159);
    address=models.CharField(max_length=159);
    status=models.CharField(max_length=159);


class cart(models.Model):
	pid=models.CharField(max_length=159);
	name=models.CharField(max_length=159);
	quantity=models.IntegerField();
	mrp=models.FloatField();
	tot_cost=models.FloatField();
	image=models.CharField(max_length=500);
	email=models.CharField(max_length=150);
	distributer=models.CharField(max_length=150);
	stz=models.CharField(max_length=15);




class alerts(models.Model):
	SKU=models.CharField(max_length=159);
	PID=models.CharField(max_length=159);
	VaccineName=models.CharField(max_length=159);
	ManufacturerEmail=models.CharField(max_length=159);
	ManufacturerName=models.CharField(max_length=159);
	RetailerName=models.CharField(max_length=159);
	RetailerEmail=models.CharField(max_length=159);
	UserName=models.CharField(max_length=159);
	UserEmail=models.CharField(max_length=159);




class alerts2(models.Model):
	SKU=models.CharField(max_length=159);
	PID=models.CharField(max_length=159);
	VaccineName=models.CharField(max_length=159);
	ManufacturerEmail=models.CharField(max_length=159);
	ManufacturerName=models.CharField(max_length=159);
	RetailerName=models.CharField(max_length=159);
	RetailerEmail=models.CharField(max_length=159);


