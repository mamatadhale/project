
from django.shortcuts import render
from django.http import HttpResponse, request
from django.conf import settings
from .models import *
import random 

from django.shortcuts import render, redirect
from django.db.models import F


from .BlockChain import load_contract_address, add_data, dataget

    


# Create your views here.
def homepage(request):
    load_contract_address()
    all_data = dataget()
    if len(all_data)==0:
        d=vaccine_stock.objects.exclude(distributer='')
        for d1 in d:
            data=[d1.sku]
            add_data(d1.distributer, data)


    return render(request, 'index.html')

def adminlogin(request):
    
    return render(request, 'admin.html', )


def adminloginaction(request):
    userid=request.POST['aid']
    pwd=request.POST['pwd']
    print(userid, pwd,'<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<')
    if userid=='admin' and pwd=="admin":
        request.session['adminid']='admin'
        return render(request, 'adminhome.html')
    else:
        err='Your Login Data is wrong !!' 
        return render(request, 'admin.html',{'msg':err})



def transporter(request):
    
    return render(request, 'transporter.html', )


def tloginaction(request):
    userid=request.POST['aid']
    pwd=request.POST['pwd']
    print(userid, pwd,'<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<')
    if userid=='transporter' and pwd=="transporter":
        request.session['transporter']='transporter'
        return render(request, 'thome.html')
    else:
        err='Your Login Data is wrong !!' 
        return render(request, 'transporter.html',{'msg':err})




def adminhome(request):
    return render(request, 'adminhome.html')



def viewmanufacturers(request):
    d=manufacturers.objects.filter(stz__exact='new')
    d2=manufacturers.objects.filter(stz__exact='Accepted')
    return render(request, 'viewmanufacturers.html',{'data': d,'data2': d2})

def viewdistributers(request):
    d=distributers.objects.filter()
    return render(request, 'viewdistributers.html',{'data': d})

def acceptor(request):
    mid=request.GET['mid']
    dec=request.GET['dec']
    
    d=manufacturers.objects.filter(id=mid).update(stz=dec)
    d=manufacturers.objects.filter(stz__exact='new')
    d2=manufacturers.objects.filter(stz__exact='Accepted')
    return render(request, 'viewmanufacturers.html',{'data': d,'data2': d2, 'msg':'Operation Done !!'})



def adminlogout(request):
    return render(request, 'admin.html')


def manufacturer(request):
    
    return render(request, 'manufacturer.html')


def msignupaction(request):
    if request.method=='POST':
        email =request.POST['mail'] 
        d=manufacturers.objects.filter(email__exact=email).count()
        if d>0:
            return render(request, 'manufacturer.html',{'msg':"Email Already Registered"})
        else:

            pass_word=request.POST['pass_word']
            city=request.POST['city']
            name=request.POST['name']
            address=request.POST['add']

            d=manufacturers(name=name,email=email,pass_word =pass_word,address=address,city=city , stz='new')
            d.save()

            return render(request, 'manufacturer.html',{'msg':"Register Success.."})
    else:
        
        return render(request, 'msignup.html')


def mloginaction(request):
    if request.method=='POST':
        uid=request.POST['mail']
        pass_word=request.POST['pass_word']
        d=manufacturers.objects.filter(email__exact=uid).filter(pass_word__exact=pass_word).filter(stz__exact='Accepted').count()
        d2=manufacturers.objects.filter(email__exact=uid).filter(pass_word__exact=pass_word).filter(stz__exact='new').count()
        
        if d>0:
            d=manufacturers.objects.filter(email__exact=uid)
            request.session['memail']=uid
            request.session['mname']=d[0].name
            
         
         
            return render(request, 'm_home.html',{'data': d[0]})

        elif d2>0:
            return render(request, 'manufacturer.html',{'msg':"Admin not accepted !!"})
        
        else:
            return render(request, 'manufacturer.html',{'msg':"Login Fail !!"})

    else:

        return render(request, 'manufacturer.html')
   
   
def mlogout(request):
    try:
        del request.session['memail']
    except:
        pass
    return render(request, 'manufacturer.html')


def mhome(request):
    if "memail" in request.session:
        memail=request.session["memail"]
        d=manufacturers.objects.filter(email__exact=memail)


       
        return render(request, 'm_home.html',{'data': d[0]})

    else:
        return redirect('mlogout')

def addvaccine(request):
    if request.method=='POST':
        name=request.POST['name']
        size=request.POST['size']
        description=request.POST['description']
        usage=request.POST['usage']
        selling_price=request.POST['selling_price']
        mrp=request.POST['mrp']
        image=request.POST['image']
        email=request.session['memail']
        mname=request.session['mname']

        d=vaccine(name=name, size=size, description=description, usage=usage, availability=0, mrp=mrp, selling_price=selling_price,  image=image, email=email, company_name=mname )
        d.save()
        return render(request, 'addvaccine.html', {'msg':'Vaccine Added !!'})
    else:
        return render(request, 'addvaccine.html')

def mviewvaccine(request):
    if "memail" in request.session:
        memail=request.session["memail"]
        d=vaccine.objects.filter(email__exact=memail)
           
        return render(request, 'mviewvaccine.html',{'data':d})

    else:
        return redirect('mlogout')

def addstock(request):
    id=request.POST['id']
    name=request.POST['name']
    
    email=request.session["memail"]
    stock=int(request.POST['stock'])

    
    
    vaccine.objects.filter(id = id).update(availability=F('availability')+stock)
    from .GenerateSKU import generate_sku

    for temp in range(stock):
        sku=generate_sku(name)

        d=vaccine_stock(sku=sku, pid=id, pname=name, manufacturer=email, distributer='', user='')
        d.save()

   
    d=vaccine.objects.filter(email__exact=email)
    
    return render(request, 'mviewvaccine.html',{'data':d, 'msg':'Stock Updated'})





def distributer(request):
    
    return render(request, 'distributer.html')


def dsignupaction(request):
    if request.method=='POST':
        email =request.POST['mail'] 
        d=distributers.objects.filter(email__exact=email).count()
        if d>0:
            return render(request, 'distributer.html',{'msg':"Email Already Registered"})
        else:

            pass_word=request.POST['pass_word']
            city=request.POST['city']
            name=request.POST['name']
            address=request.POST['add']
            phone=request.POST['phone']
            typ_e=request.POST['type']

            d=distributers(name=name,typ_e=typ_e,email=email,pass_word=pass_word,address=address,city=city, phone=phone )
            d.save()

            return render(request, 'distributer.html',{'msg':"Register Success.."})
    else:
        
        return render(request, 'dsignup.html')


def dloginaction(request):
    if request.method=='POST':
        uid=request.POST['mail']
        pass_word=request.POST['pass_word']
        d=distributers.objects.filter(email__exact=uid).filter(pass_word__exact=pass_word).count()
        
        
        if d>0:
            d=distributers.objects.filter(email__exact=uid)
            request.session['demail']=uid
            request.session['dname']=d[0].name
            
         
         
            return render(request, 'd_home.html',{'data': d[0]})

       
        else:
            return render(request, 'distributer.html',{'msg':"Login Fail !!"})

    else:

        return render(request, 'distributer.html')
   
   
def dlogout(request):
    try:
        del request.session['demail']
    except:
        pass
    return render(request, 'distributer.html')


def dhome(request):
    if "demail" in request.session:
        demail=request.session["demail"]
        d=distributers.objects.filter(email__exact=demail)
        return render(request, 'd_home.html',{'data': d[0]})

    else:
        return redirect('dlogout')

def dviewvaccine(request):
    if request.method=="POST":
        memail=request.POST["memail"]
        d=vaccine.objects.filter(email__exact=memail)
        return render(request, 'dviewvaccine.html',{'data':d})
    else:
        d=vaccine.objects.filter()
        return render(request, 'dviewvaccine.html',{'data':d})






def user(request):
    request.session['head']='User Login'
    return render(request, 'users.html')


def usignupaction(request):
    if request.method=='POST':
        email =request.POST['mail'] 
        d=users.objects.filter(email__exact=email).count()
        if d>0:
            return render(request, 'users.html',{'msg':"Email Already Registered"})
        else:

            pass_word=request.POST['pass_word']
            name=request.POST['name']
            phone=request.POST['phone']

            d=users(name=name,email=email,pass_word =pass_word,phone=phone)
            d.save()

            return render(request, 'users.html',{'msg':"Register Success.."})
    else:
        request.session['head']='User Signup'
        return render(request, 'usignup.html')


def uloginaction(request):
    if request.method=='POST':
        uid=request.POST['mail']
        pass_word=request.POST['pass_word']
        d=users.objects.filter(email__exact=uid).filter(pass_word__exact=pass_word).count()
        
        
        if d>0:
            d=users.objects.filter(email__exact=uid)
            request.session['uemail']=uid
            request.session['uname']=d[0].name
            request.session['head']='User Portal'

            # prev=vaccine_stock.objects.filter(user=uid)

            # load_contract_address()
            # for p1 in prev:
            #     data=[p1.sku]
            #     add_data(uid, data)
            

         
         
            return render(request, 'u_home.html',{'data': d[0]})

       
        
        else:
            return render(request, 'users.html',{'msg':"Login Fail !!"})

    else:

        return render(request, 'users.html')
   
   
def ulogout(request):
    try:
        del request.session['uemail']
    except:
        pass
    return render(request, 'users.html')


def uhome(request):
    if "uemail" in request.session:

        memail=request.session["uemail"]
        d=users.objects.filter(email__exact=memail)
        return render(request, 'u_home.html',{'data': d[0]})

    else:
        return redirect('ulogout')


def profile(request):
    if "uemail" in request.session:
        uid = request.session["uemail"]
        d = users.objects.filter(email__exact=uid)
      
        return render(request, 'profile.html', {'data': d[0],  })

    else:
        return render(request, 'users.html')



def manageaddress(request):
    if request.method == 'POST':
        email = request.session["uemail"]
        addr = request.POST['addr']

        addrtype = request.POST['addrtype']
        city = request.POST['city']
        zip = request.POST['zip']

        d = user_address(email=email, addr_type=addrtype, address=addr, zip=zip, city=city)
        d.save()
        d = users.objects.filter(email__exact=email)
        
        return render(request, 'profile.html', {'data': d[0],'msg':'Address Added !!'})
    else:
        email = request.session["uemail"]
        d = user_address.objects.filter(email=email)
        return render(request, 'manageaddress.html', {'data': d})

def deleteaddress(request):
    if request.method == 'GET':

        addr = request.GET['id']
        d = user_address.objects.filter(id=addr)
        print(d[0])
        d.delete()

        return redirect('manageaddress')
    else:
        pass



def pstockget(request):
    d=vaccine.objects.filter()
    import string


    orderid = ''.join(random.choices(string.digits, k=4))  # Generate 4-digit random number
    

    email=request.session['demail']
    name=request.session['dname']
    for d1 in d:
        id=d1.id
        try:
            load_contract_address()
            order=int(request.POST[str(id)])
            if order>0:
                records = vaccine_stock.objects.filter(pid=id, distributer='')[:order]
                for record in records:
                    record.distributer = email
                    sk=[record.sku]
                    add_data(email, sk)
                print(records, '<<<<<<<<')
                    
                vaccine_stock.objects.bulk_update(records, ["distributer"])
                vaccine.objects.filter(id = id).update(availability=F('availability')-order)
                
                d=DistributerOrders(orderid=orderid, pid=id, pname=d1.name, quantity=order, cost=d1.selling_price, tot_cost=order*d1.selling_price, manufacturer=d1.email, manufacturer_name=d1.company_name, distributer_name=name, distributer_email=email)
                d.save()
        except ValueError as e:
            print(e)
            d=vaccine.objects.filter()
            return render(request, 'dviewvaccine.html',{'data':d, 'msg':'Place minimum order !!'})


    d=vaccine.objects.filter()
    return render(request, 'dviewvaccine.html',{'data':d, 'msg':'Order Placed !!'})


def morders(request):
    email=request.session['memail']
    orders = DistributerOrders.objects.filter(manufacturer=email).values('orderid', 'distributer_email', 'distributer_name', 'date', 'status').distinct()
    return render(request, 'morders.html',{'data':orders, })

def morderview(request):
    orderid=request.POST['orderid']
    distributer_name=request.POST['distributer_name']
    distributer_email=request.POST['distributer_email']
    orders = DistributerOrders.objects.filter(orderid=orderid)
    tot=0
    for o in orders:
        tot+=o.tot_cost
    return render(request, 'morderview.html',{'data':orders, 'tot':tot, 'distributer_email':distributer_email, 'distributer_name':distributer_name})



   
def tlogout(request):
    try:
        del request.session['transporter']
    except:
        pass
    return render(request, 'transporter.html')


def thome(request):
    if "transporter" in request.session:
        
        return render(request, 'thome.html',{})

    else:
        return redirect('tlogout')




def transfer(request):
    orderid=request.POST['orderid']
    distributer_name=request.POST['distributer_name']
    distributer_email=request.POST['distributer_email']
    manufacturer=request.session['mname']
    manufacturer_email=request.session['memail']
    
    data=distributers.objects.filter(email=distributer_email)
    data=data[0]

    address=data.address
    city=data.address
    phone=data.phone

    d=Transport(orderid=orderid, distributer_name=distributer_name, distributer_email=distributer_email, address=address, city=city,phone=phone, manufacturer_name=manufacturer, manufacturer=manufacturer_email,status='Delivery Initiated')
    d.save()

    DistributerOrders.objects.filter(manufacturer=manufacturer_email, orderid=orderid).update(status='Delivery Initiated')
    
    return redirect('morders')


def delivery(request):
    data = Transport.objects.filter()
    return render(request, 'delivery.html',{'data':data})


def delivered(request):
    orderid=request.POST['orderid']
    manufacturer=request.POST['manufacturer']
    id=request.POST['id']
    
    Transport.objects.filter(id=id).update(status='Delivered')
    DistributerOrders.objects.filter(manufacturer=manufacturer, orderid=orderid).update(status='Delivered')
    
    return redirect('delivery')


def orderstatus(request):
    demail=request.session['demail']

    data = Transport.objects.filter(distributer_email=demail)
    return render(request, 'orderstatus.html',{'data':data})


def inventory(request):
    data=[]
    email=request.session['demail']

    d=vaccine_stock.objects.filter(distributer=email).values('pid', 'pname').distinct()
    d=list(d)
    for d1 in d:
        pid=d1['pid']
        pname=d1['pname']
        stock=0
        stock=vaccine_stock.objects.filter(distributer=email, pid=pid, user='').count()
        data.append({'pid':pid, 'pname':pname, 'stock':stock})


    return render(request, 'inventory.html',{'data':data})


def viewvaccine(request):
    if "uemail" in request.session:
        d=vaccine.objects.filter()
           
        return render(request, 'viewvaccine.html',{'data':d})

    else:
        return redirect('ulogout')


def viewdata(request, op):
    if "uemail" in request.session:
        d=vaccine.objects.filter(id=op)
        d2 = vaccine_stock.objects.filter(pid=op, user='').exclude(distributer='')[:1]
        c=d2.count()
        if c>0:
            vendor=d2[0].distributer
            stock = vaccine_stock.objects.filter(pid=op, user='', distributer=vendor).count()
            return render(request, 'viewdata.html',{'d1':d[0], 'vendor':vendor, 'stock':stock})
        else:
            return render(request, 'viewdata.html',{'d1':d[0], 'msg':'No Stocks', 'stz':True })
    else:
        return redirect('ulogout')



def addtocart(request):
    if request.method == 'POST':
        email = request.session["uemail"]
        seller = request.POST['seller']

        pid = request.POST['id']
        image = request.POST['image']
        name = request.POST['name']
        quantity = int(request.POST['count'])
        mrp = float(request.POST['mrp'])

        d = cart(pid=pid, name=name, quantity=quantity, mrp=mrp, tot_cost=mrp*quantity, image=image, email=email, distributer=seller, stz='new')
        d.save()
        
        
        return render(request, 'u_home.html', {'msg':'Item Added to cart !!'})
    else:
        pass

def uviewcart(request):
    email=request.session['uemail']
    if request.method=='POST':
        
        from django.db.models import F
        
        c1=cart.objects.filter(email=email).filter(stz="new")
        sum=0
       
        for c11 in c1:
            #drugstock_p.objects.filter(did = c11.did).update(stock=F('stock')+c11.count)
            sum=sum+c11.tot_cost
        

        d=cart.objects.filter(email=email, stz='new')
        for d1 in d:
            id=d1.pid
            seller=d1.distributer
            try:
                order=d1.quantity

                if order>0:
                    records = vaccine_stock.objects.filter(pid=id, distributer=seller)[:order]
                    for record in records:
                        record.user = email
                    vaccine_stock.objects.bulk_update(records, ["user"])
                    #vaccine.objects.filter(id = id).update(availability=F('availability')-order)
                
                    
                    
                    
            except ValueError as e:
                
                return render(request, 'u_home.html',{ 'msg':e})
        
        prev=vaccine_stock.objects.filter(user=email)
        # load_contract_address()
        # for p1 in prev:
        #     data=[p1.sku]
        #     add_data(email, data)

        cart.objects.filter(stz='new').filter(email=email).update(stz='done')


        



        
        return render(request, 'pay.html',{'amt':sum, })

    else:
        c1=cart.objects.filter(email=email, stz="new")
        return render(request, 'viewcart_u.html',{'data':c1, })

def payment_u(request):
    email=request.session['uemail']
    if request.method=='POST':
        
        return render(request, 'u_home.html',{'msg':'Thank you for your purchase !!', })

    else:
        pass


def vieworders(request):
    email=request.session['uemail']
    d=cart.objects.filter(stz='done', email=email)
    return render(request, 'vieworders.html',{'data':d, })




import qrcode
import base64
import json
from io import BytesIO

def verify(request):
    email=request.session['uemail']
    pid=request.POST['pid']
    print(pid, '<<<<<<<<<<<<<<<<<<<<')
    d=vaccine_stock.objects.filter(user=email,pid=pid)
    print(d)
    prod_data=vaccine.objects.filter(id=pid)[0]
    data=[]
    for d1 in d:
        sku=d1.sku
        name=prod_data.name
        manufacturer_name=prod_data.company_name
        manufacturer_email=prod_data.email
        distributer_email=d1.distributer
        distributer_name=distributers.objects.filter(email=distributer_email)[0].name

        qr_data={'SKU':sku,'VaccineName':name, "PID":pid ,"ManufacturerName":manufacturer_name,
        "ManufacturerEmail":manufacturer_email,
        'DistributerName':distributer_name, 'DistributerEmail':distributer_email
        }
        print(qr_data)
        
        dict_data=qr_data
        
        qr_json = json.dumps(qr_data)
        qr = qrcode.make(qr_json)
        buffer = BytesIO()
        qr.save(buffer, format="PNG")
        qr_base64 = base64.b64encode(buffer.getvalue()).decode()  # Convert to base64 for embedding in HTML
        dict_data['qr_image']=qr_base64
        data.append(dict_data)
        print(data)

    
    return render(request, 'vieworders2.html',{'data':data, })


def dvieworders(request):
    email=request.session['demail']
    d = cart.objects.filter(stz='done', distributer=email).order_by('-id')
    return render(request, 'dvieworders.html',{'data':d, })


def dropimage(request):
    return render(request, 'dropimage.html',)

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
import os

@csrf_exempt
def dropimageaction(request):
    if request.method == "POST" and request.FILES.get("image"):
        image_file = request.FILES["image"]
        file_path = os.path.join("uploads", image_file.name)

        # Save image in media/uploads
        saved_path = default_storage.save(file_path, ContentFile(image_file.read()))
        full_image_path = os.path.join(settings.MEDIA_ROOT, saved_path)

        from .QRData import decode_qr
        res=decode_qr(full_image_path)

        
        request.session['res']=res

        print(res, '<<<<<<<<<<<<<<<')


        return JsonResponse({"message": "Image uploaded successfully", "file_path": saved_path})
    
    return JsonResponse({"error": "Invalid request"}, status=400)


def viewres(request):
    email=request.session['uemail']
    name=request.session['uname']
    res=request.session['res']
    print(res, 'QQQQQQQQQQQQQQQQQQQQQQQQQQ')
    sku=res['SKU']
    load_contract_address()
    all_data = dataget()
    verification=False
    for entry in all_data:
        b_sku = entry[0]
        if b_sku==sku:
            verification=True
    if verification:
        pass
    else:
        d=alerts(SKU=res['SKU'], PID=res['PID'],VaccineName=res['VaccineName'],  ManufacturerEmail=res['ManufacturerEmail'], ManufacturerName=res['ManufacturerName'], RetailerName=res['DistributerName'], RetailerEmail=res['DistributerEmail'], UserEmail=email, UserName=name )
        d.save()

        
    return render(request, 'viewres.html',{'data':res, 'stz':verification})



def getall(request):
    email=request.session['demail']
    pid=request.GET['pid']
    print(pid, '<<<<<<<<<<<<<<<<<<<<')
    d=vaccine_stock.objects.filter(distributer=email,pid=pid)
    print(d)
    prod_data=vaccine.objects.filter(id=pid)[0]
    data=[]
    for d1 in d:
        sku=d1.sku
        name=prod_data.name
        manufacturer_name=prod_data.company_name
        manufacturer_email=prod_data.email
        distributer_email=d1.distributer
        distributer_name=distributers.objects.filter(email=distributer_email)[0].name

        qr_data={'SKU':sku,'VaccineName':name, "PID":pid ,"ManufacturerName":manufacturer_name,
        "ManufacturerEmail":manufacturer_email,
        'DistributerName':distributer_name, 'DistributerEmail':distributer_email
        }
        print(qr_data)
        
        dict_data=qr_data
        
        qr_json = json.dumps(qr_data)
        qr = qrcode.make(qr_json)
        buffer = BytesIO()
        qr.save(buffer, format="PNG")
        qr_base64 = base64.b64encode(buffer.getvalue()).decode()  # Convert to base64 for embedding in HTML
        dict_data['qr_image']=qr_base64
        data.append(dict_data)
        print(data)

    
    return render(request, 'getall.html',{'data':data, })


    

def d_dropimage(request):
    return render(request, 'd_dropimage.html',)


def viewres2(request):
    email=request.session['demail']
    name=request.session['dname']
    res=request.session['res']
    print(res, 'QQQQQQQQQQQQQQQQQQQQQQQQQQ')
    sku=res['SKU']
    load_contract_address()
    all_data = dataget()
    verification=False
    for entry in all_data:
        b_sku = entry[0]
        if b_sku==sku:
            verification=True
    if verification:
        pass
    else:
        d=alerts2(SKU=res['SKU'], PID=res['PID'],VaccineName=res['VaccineName'],  ManufacturerEmail=res['ManufacturerEmail'], ManufacturerName=res['ManufacturerName'], RetailerName=res['DistributerName'], RetailerEmail=res['DistributerEmail'], )
        d.save()

        
    return render(request, 'viewres2.html',{'data':res, 'stz':verification})

def viewalerts(request):
    d= alerts.objects.all()
    d2= alerts2.objects.all()
    return render(request, 'alerts.html',{'data':d,'data2':d2, })